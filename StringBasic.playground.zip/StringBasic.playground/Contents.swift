var twoWord: String = "Hello world"
let name: String = "Chien-an Lin"

twoWord + " " + name

twoWord = twoWord + name

twoWord += name

twoWord.lowercased()
twoWord.uppercased()



