var fruitArray = ["apple","banana","cherry","berry"] // 陣列的計算是從0開始

fruitArray[0]
fruitArray[2]

fruitArray.count // 計算陣列總數

fruitArray.append("bell") //加入新的陣列 從最後一個開始加入

fruitArray.insert("cell", at: 1) //加入新的陣列 但可以選擇要加入到第幾個

fruitArray.remove(at: 5) //移動陣列 at 有指定第幾個陣列要被移除

fruitArray

fruitArray.removeLast() //移除最後一個陣列數

fruitArray.removeFirst() //移除第一個陣列數

fruitArray.reverse() //要陣列順序前後顛倒

fruitArray = fruitArray.reversed()

var animalArray = ["dog","cat","human"]

fruitArray = fruitArray + animalArray //要將兩個陣列相加 直接用+號即可

fruitArray[0] = "baby" //要替換陣列只需要宣告第幾號陣列 然後=什麼String 就行了

fruitArray

fruitArray.removeAll()//移除所有陣列





