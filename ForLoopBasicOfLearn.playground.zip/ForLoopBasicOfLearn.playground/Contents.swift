
var countNum = (0...10)


var anotherNumArray:[Int] = []


for num in countNum {
    anotherNumArray.append(num + 2) //將新的數加入新的陣列
}

let nameArray = ["John","Jane","Ray","Kerry"]

var lowerCaseNameArray:[String] = []

for name in nameArray {
    print(name)
    lowerCaseNameArray.append(name.lowercased()) //將陣列改成小寫 並加入到新的陣列中
}

print(lowerCaseNameArray)


for index in 1..<100{ //半閉 迴圈到100-1 = 99
    print(index)
}

//99乘法表
for i in 1...9 {
    //第i次
    for index in 1...9{
     //執行i*index
     var answer = i * index
     print("\(i) * \(index) = \(answer)")
     print("")
    }
}

//加入where條件
for i in 1...10 where i % 2 == 0 {
    print(i)
}

//dict
//如何使用for迴圈取得dict裡的key,value
var fruitDit = ["red":"apple","yellow":"banana"]

for (Key,Value) in fruitDit {
    print(Key + ":" + Value)
}

//Tuple
//使用() 來宣告
let color = ("red","orange","yellow","green","blue")
//要取得值 只需要用變數名稱後面加上.第幾號
color.0
//tuple同時也可以用於多種型態
let somethingTuple = (123,true,2.33,["apple","mac"])

somethingTuple.1

somethingTuple.3[1]

var fruitTuple = (red:"apple",blue:"blueberry",orange:"orange")

fruitTuple.red

fruitTuple.0



