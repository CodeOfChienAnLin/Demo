

//字典的應用


var fruitDict:[String:String] = ["red":"apple","yellow":"banana","green":"mango"] //前面的值是Key,後面的值是Value

fruitDict["red"]

fruitDict["yellow"] = "passion" //直接替換掉yellow裡面的value值

fruitDict.updateValue("peach", forKey: "pink") //這樣寫會是一個nil 因為沒有peach這個key

fruitDict["orange"] = "orange" // 直接新增一組

fruitDict

fruitDict.updateValue("strawberry", forKey: "red") //要取代舊值 前面是新的String 後面則是要用在哪個Key

fruitDict["red"] = nil //直接讓他變空值 nil表示空值

fruitDict

fruitDict.removeValue(forKey: "green") //指定移除掉第幾個Key

fruitDict

var score:[String:Int] = ["english":90,"chinese":80,"sports":70]

score["english"] = 70

score






