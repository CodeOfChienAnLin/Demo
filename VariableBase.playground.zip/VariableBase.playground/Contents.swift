var x = 1
x + 3
x = 2

class Tcount {
    var top: Int = 0
    var bottom: Int = 0
    var height: Int = 0
    
    init?(top: Int,bottom: Int,height: Int){
        
        self.top = top
        self.bottom = bottom
        self.height = height
    }
 
    func area () -> Int {
        return (top + bottom) * height / 2
    }
}

var tcount = Tcount(top: 2,bottom: 3,height: 5)
tcount!.area()

var y: Float = 2.3

Float(x) * y


